#!/usr/bin/env python
from brain_games import logic


def main():
    logic.play_brain_even()


if __name__ == '__main__':
    main()
